
#include <luaconf.h>

// constants from lstrlib.c

#define MAX_ITEM        512
#define FLAGS   "-+ #0"
#define MAX_FORMAT      (sizeof(FLAGS) + sizeof(LUA_INTFRMLEN) + 10)
