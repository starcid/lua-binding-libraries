/** \file
 * \brief Dummy WMF
 *
 * See Copyright Notice in cd.h
 */

#include <stdlib.h>
#include "cd.h"
#include "cdwmf.h"


cdContext* cdContextWMF(void)
{
  return NULL;
}

