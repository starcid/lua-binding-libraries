return {
  "strict",
  "base",
  "debug_ext",
  "table_ext",
  "list",
  "tree",
  "object",
  "string_ext",
  "math_ext",
  "io_ext",
  "getopt",
  "set",
}
