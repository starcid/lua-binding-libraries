The output libraries are created here.
