This dir is filled with the output of running 
$doxygen doxygen.cfg in wxLua/docs.
